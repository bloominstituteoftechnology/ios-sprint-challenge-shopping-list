//
//  ShoppingListController.swift
//  Shopping List
//
//  Created by Lambda_School_Loaner_268 on 2/7/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation

let itemsKey = "ItemsKey"
class ShoppingListController {
    var shoppingItems: [ShoppingItem] = []
    
    
    let names = ["Apple", "Grapes", "Milk", "Muffin", "Popcorn", "Soda", "Strawberries"]
    
    
    let items = UserDefaults.standard.bool(forKey: itemsKey)
    
  
    var notAddedItems: [ShoppingItem] {
        let notAdded = shoppingItems.filter { return !$0.beenAdded }
        return notAdded
    }
    
    var addedItems: [ShoppingItem] {
                let added = shoppingItems.filter { return $0.beenAdded }
                return added
            }
    
   
    
     func addedToggled(for item: ShoppingItem) {
            guard let index = shoppingItems.firstIndex(of: item) else { return }
            shoppingItems[index].beenAdded.toggle()
            saveToPersistentStore()
        }
        func fetchItems() {
            if items {
                loadFromPersistentStore()
            } else {
                create()
                saveToPersistentStore()
                UserDefaults.standard.set(true, forKey: itemsKey)
            }
        }
        
        //MARK: -Persistence
        
        //Create Items
        func create() {
            for item in names {
                let item = ShoppingItem(item: item, beenAdded: true)
                shoppingItems.append(item)
            }
        }
        private var persistentFileURL: URL? {
            let fm = FileManager.default
            guard let dir = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
            return dir.appendingPathComponent("shoppingList-items.plist")
           }
           
        private func saveToPersistentStore() {
            guard let url = persistentFileURL else { return }
            do {
                let encoder = PropertyListEncoder()
                let data = try encoder.encode(shoppingItems)
                try data.write(to: url)
            } catch {
                print("Error saving shoppingItems data: \(error)")
            }
        }
        func loadFromPersistentStore() {
            let fm = FileManager.default
            guard let url = persistentFileURL,
                fm.fileExists(atPath: url.path) else { return }
            do{
                let data = try Data(contentsOf: url)
                let decoder = PropertyListDecoder()
                shoppingItems = try decoder.decode([ShoppingItem].self, from: data)
            } catch {
                print("Error loading shoppingItems data: \(error)")
            }
        }
    }
