//
//  ShoppingItem.swift
//  Shopping List
//
//  Created by Lambda_School_Loaner_268 on 2/7/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation
import UIKit

struct ShoppingItem: Codable, Equatable {
    var item: String
    var beenAdded: Bool
    
}

