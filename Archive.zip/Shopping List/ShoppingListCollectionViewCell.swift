//
//  ShoppingListCollectionViewCell.swift
//  Shopping List
//
//  Created by Lambda_School_Loaner_268 on 2/9/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit

class ShoppingListCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var shoppingListImageView: UIImageView!
    @IBOutlet weak var beenAddedLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBAction func itemTapped(_ sender: Any) {
           delegate?.ItemTapped(forItem: self)
       }
    
    var delegate: ShoppingListCollectionViewCellDelegate?
    
    var item: ShoppingItem? {
        didSet {
            updateViews()
        }
    }
    func updateViews() {
        guard let item = item, let image = UIImage(named: item.item) else { return }
        var addedText = ""
        if item.beenAdded {
           addedText = "Added"
       } else {
           addedText = "Not Added"
       }
       
       beenAddedLabel.text = addedText
        shoppingListImageView.image = image
       nameLabel.text = item.item
   }
    
    
    
}
