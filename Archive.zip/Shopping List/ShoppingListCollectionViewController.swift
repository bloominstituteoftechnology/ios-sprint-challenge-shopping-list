//
//  ShoppingListCollectionViewController.swift
//  Shopping List
//
//  Created by Lambda_School_Loaner_268 on 2/9/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit
private let reuseIdentifier = "Cell"
protocol ShoppingListCollectionViewCellDelegate: AnyObject {
    func ItemTapped(forItem item: ShoppingListCollectionViewCell)
}
class ShoppingListCollectionViewController: UICollectionViewController {

    // MARK: - Properties
    
    let shoppingListController: ShoppingListController = ShoppingListController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        shoppingListController.fetchItems() // Load items to collection view
    }
    
    // MARK: - Methods
    private func itemFor(_ indexPath: IndexPath) -> ShoppingItem {
        switch indexPath.section {
        case 0:
            return shoppingListController.addedItems[indexPath.item]
        default:
            return shoppingListController.notAddedItems[indexPath.item]
        }
    }
    
    // MARK: - Navigation

     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let detailVC = segue.destination as? ShoppingListDetailViewController else { return }
        //set number of items
        detailVC.itemCount = shoppingListController.shoppingItems.filter( {$0.beenAdded} ).count
    }

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0:
            print(shoppingListController.notAddedItems.count)
            return shoppingListController.addedItems.count
        default:
            return shoppingListController.notAddedItems.count
        }
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as? ShoppingListCollectionViewCell else { return UICollectionViewCell() }
        cell.delegate = self as ShoppingListCollectionViewCellDelegate
        cell.item = itemFor(indexPath)
        return cell
    }
}

// MARK: - Extensions

extension ShoppingListCollectionViewController: ShoppingListCollectionViewCellDelegate {
    func ItemTapped(forItem item: ShoppingListCollectionViewCell) {
        guard let item = item.item else { return }
        
        shoppingListController.addedToggled(for: item)
        collectionView?.reloadData()
    }
}
