//
//  ShoppingListDetailViewController.swift
//  Shopping List
//
//  Created by Lambda_School_Loaner_268 on 2/9/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit

class ShoppingListDetailViewController: UIViewController {
    
    @IBOutlet weak var shoppingListCountLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var orderButton: UIButton!
    
    var itemCount: Int?
    
    @IBAction func orderButtonTapped(_ sender: Any) {
        if let name = nameTextField.text, !name.isEmpty, let address = addressTextField.text, !address.isEmpty {
            let title = "Delivery For \(name)"
            let body = "Your order will be delivered to \(address) in 15 minutes"
            
            navigationController?.popViewController(animated: true)
            
            NotificationCenter.sharedNotificationCenter.sendNotification(title: title, message: body)
            
        }
        
    }
       
    var shoppingItemCount: Int?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()

        // Do any additional setup after loading the view.
    }
    
    func updateViews() {
        guard let itemCount = itemCount else { return }
            shoppingListCountLabel.text = "You have \(itemCount) item(s) in your shopping list."
        }
        
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


